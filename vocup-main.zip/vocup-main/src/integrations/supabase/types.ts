export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.5"
  }
  public: {
    Tables: {
      careers: {
        Row: {
          area: string | null
          created_at: string
          demanda_laboral: string | null
          descripcion: string | null
          duracion: string | null
          habilidades: string[] | null
          id: string
          nombre: string
          salario_promedio: string | null
        }
        Insert: {
          area?: string | null
          created_at?: string
          demanda_laboral?: string | null
          descripcion?: string | null
          duracion?: string | null
          habilidades?: string[] | null
          id?: string
          nombre: string
          salario_promedio?: string | null
        }
        Update: {
          area?: string | null
          created_at?: string
          demanda_laboral?: string | null
          descripcion?: string | null
          duracion?: string | null
          habilidades?: string[] | null
          id?: string
          nombre?: string
          salario_promedio?: string | null
        }
        Relationships: []
      }
      chat_messages: {
        Row: {
          content: string
          created_at: string
          id: string
          role: string
          user_id: string
        }
        Insert: {
          content: string
          created_at?: string
          id?: string
          role: string
          user_id: string
        }
        Update: {
          content?: string
          created_at?: string
          id?: string
          role?: string
          user_id?: string
        }
        Relationships: []
      }
      favorites: {
        Row: {
          career_id: string
          created_at: string
          id: string
          user_id: string
        }
        Insert: {
          career_id: string
          created_at?: string
          id?: string
          user_id: string
        }
        Update: {
          career_id?: string
          created_at?: string
          id?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "favorites_career_id_fkey"
            columns: ["career_id"]
            isOneToOne: false
            referencedRelation: "careers"
            referencedColumns: ["id"]
          },
        ]
      }
      mascots: {
        Row: {
          accesorios: string[] | null
          color: string
          estado: string
          monedas: number
          nivel: number
          updated_at: string
          user_id: string
          xp: number
        }
        Insert: {
          accesorios?: string[] | null
          color?: string
          estado?: string
          monedas?: number
          nivel?: number
          updated_at?: string
          user_id: string
          xp?: number
        }
        Update: {
          accesorios?: string[] | null
          color?: string
          estado?: string
          monedas?: number
          nivel?: number
          updated_at?: string
          user_id?: string
          xp?: number
        }
        Relationships: []
      }
      profiles: {
        Row: {
          created_at: string
          edad: number | null
          email: string | null
          id: string
          nombre: string | null
          pais: string | null
          updated_at: string
        }
        Insert: {
          created_at?: string
          edad?: number | null
          email?: string | null
          id: string
          nombre?: string | null
          pais?: string | null
          updated_at?: string
        }
        Update: {
          created_at?: string
          edad?: number | null
          email?: string | null
          id?: string
          nombre?: string | null
          pais?: string | null
          updated_at?: string
        }
        Relationships: []
      }
      universities: {
        Row: {
          carreras: string[] | null
          costo: string | null
          created_at: string
          id: string
          modalidad: string | null
          nombre: string
          pais: string | null
          ubicacion: string | null
        }
        Insert: {
          carreras?: string[] | null
          costo?: string | null
          created_at?: string
          id?: string
          modalidad?: string | null
          nombre: string
          pais?: string | null
          ubicacion?: string | null
        }
        Update: {
          carreras?: string[] | null
          costo?: string | null
          created_at?: string
          id?: string
          modalidad?: string | null
          nombre?: string
          pais?: string | null
          ubicacion?: string | null
        }
        Relationships: []
      }
      user_roles: {
        Row: {
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          id?: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
      vocational_profiles: {
        Row: {
          carreras_sugeridas: string[] | null
          fortalezas: string[] | null
          habilidades: string[] | null
          intereses: string[] | null
          materias_favoritas: string[] | null
          nivel_certeza: number
          objetivos: string | null
          onboarding_completo: boolean
          personalidad: string | null
          resultados_ia: Json | null
          updated_at: string
          user_id: string
        }
        Insert: {
          carreras_sugeridas?: string[] | null
          fortalezas?: string[] | null
          habilidades?: string[] | null
          intereses?: string[] | null
          materias_favoritas?: string[] | null
          nivel_certeza?: number
          objetivos?: string | null
          onboarding_completo?: boolean
          personalidad?: string | null
          resultados_ia?: Json | null
          updated_at?: string
          user_id: string
        }
        Update: {
          carreras_sugeridas?: string[] | null
          fortalezas?: string[] | null
          habilidades?: string[] | null
          intereses?: string[] | null
          materias_favoritas?: string[] | null
          nivel_certeza?: number
          objetivos?: string | null
          onboarding_completo?: boolean
          personalidad?: string | null
          resultados_ia?: Json | null
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
    }
    Enums: {
      app_role: "admin" | "estudiante"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: ["admin", "estudiante"],
    },
  },
} as const
